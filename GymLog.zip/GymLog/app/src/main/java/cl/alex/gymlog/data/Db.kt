package cl.alex.gymlog.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.io.File

// ---------- Modelos ----------

const val TYPE_STRENGTH = 0
const val TYPE_CARDIO = 1

data class Category(val id: Long, val name: String, val color: Long)

data class Exercise(
    val id: Long,
    val name: String,
    val categoryId: Long,
    val categoryName: String,
    val type: Int,
    val restSec: Int,
    val notes: String,
    val color: Long
)

data class WorkoutSet(
    val id: Long,
    val date: String,
    val exerciseId: Long,
    val order: Int,
    val weight: Double,
    val reps: Int,
    val rpe: Double?,
    val distance: Double,
    val durationSec: Int,
    val note: String
)

data class Routine(val id: Long, val name: String)
data class RoutineDay(val id: Long, val routineId: Long, val name: String, val order: Int)

data class RoutineItem(
    val id: Long,
    val dayId: Long,
    val exerciseId: Long,
    val exerciseName: String,
    val order: Int,
    val sets: Int,
    val repMin: Int,
    val repMax: Int,
    val increment: Double
)

data class BodyEntry(
    val id: Long,
    val date: String,
    val weight: Double?,
    val bodyFat: Double?,
    val waist: Double?,
    val note: String
)

data class DayExercise(val exercise: Exercise, val sets: List<WorkoutSet>, val item: RoutineItem?)

/** Fila para estadísticas generales (progreso). */
data class StatRow(
    val date: String,
    val exerciseId: Long,
    val exerciseName: String,
    val category: String,
    val color: Long,
    val type: Int,
    val weight: Double,
    val reps: Int
)

// ---------- Base de datos ----------

class DbHelper(ctx: Context) : SQLiteOpenHelper(ctx, NAME, null, 1) {
    companion object {
        const val NAME = "gymlog.db"
    }

    override fun onConfigure(db: SQLiteDatabase) {
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE category(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, color INTEGER NOT NULL DEFAULT 0)")
        db.execSQL(
            "CREATE TABLE exercise(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, " +
                "category_id INTEGER REFERENCES category(id) ON DELETE SET NULL, type INTEGER NOT NULL DEFAULT 0, " +
                "rest_sec INTEGER NOT NULL DEFAULT 90, notes TEXT)"
        )
        db.execSQL(
            "CREATE TABLE workout_set(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, " +
                "exercise_id INTEGER NOT NULL REFERENCES exercise(id) ON DELETE CASCADE, ord INTEGER NOT NULL DEFAULT 0, " +
                "weight REAL NOT NULL DEFAULT 0, reps INTEGER NOT NULL DEFAULT 0, rpe REAL, distance REAL NOT NULL DEFAULT 0, " +
                "duration INTEGER NOT NULL DEFAULT 0, note TEXT)"
        )
        db.execSQL("CREATE INDEX idx_set_date ON workout_set(date)")
        db.execSQL("CREATE INDEX idx_set_ex ON workout_set(exercise_id, date)")
        db.execSQL("CREATE TABLE routine(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)")
        db.execSQL(
            "CREATE TABLE routine_day(id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "routine_id INTEGER NOT NULL REFERENCES routine(id) ON DELETE CASCADE, name TEXT NOT NULL, ord INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL(
            "CREATE TABLE routine_item(id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "day_id INTEGER NOT NULL REFERENCES routine_day(id) ON DELETE CASCADE, " +
                "exercise_id INTEGER NOT NULL REFERENCES exercise(id) ON DELETE CASCADE, ord INTEGER NOT NULL DEFAULT 0, " +
                "sets INTEGER NOT NULL DEFAULT 3, rep_min INTEGER NOT NULL DEFAULT 8, rep_max INTEGER NOT NULL DEFAULT 12, " +
                "increment REAL NOT NULL DEFAULT 2.5)"
        )
        db.execSQL(
            "CREATE TABLE day_plan(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, " +
                "exercise_id INTEGER NOT NULL REFERENCES exercise(id) ON DELETE CASCADE, item_id INTEGER, ord INTEGER NOT NULL DEFAULT 0, " +
                "UNIQUE(date, exercise_id))"
        )
        db.execSQL(
            "CREATE TABLE body(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, weight REAL, body_fat REAL, waist REAL, note TEXT)"
        )
        seed(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    private fun seed(db: SQLiteDatabase) {
        val cats = linkedMapOf(
            "Pecho" to 0xFFE57373, "Espalda" to 0xFF64B5F6, "Hombros" to 0xFFFFB74D,
            "Bíceps" to 0xFFBA68C8, "Tríceps" to 0xFF4DB6AC, "Piernas" to 0xFF81C784,
            "Glúteos" to 0xFFF06292, "Abdomen" to 0xFFFFF176, "Cardio" to 0xFF90A4AE
        )
        val catIds = HashMap<String, Long>()
        cats.forEach { (n, c) ->
            catIds[n] = db.insert("category", null, ContentValues().apply { put("name", n); put("color", c) })
        }
        val ex = listOf(
            Triple("Press banca plano", "Pecho", 0), Triple("Press inclinado con mancuernas", "Pecho", 0),
            Triple("Aperturas en polea", "Pecho", 0), Triple("Fondos", "Pecho", 0),
            Triple("Dominadas", "Espalda", 0), Triple("Remo con barra", "Espalda", 0),
            Triple("Jalón al pecho", "Espalda", 0), Triple("Remo en polea baja", "Espalda", 0),
            Triple("Press militar", "Hombros", 0), Triple("Elevaciones laterales", "Hombros", 0),
            Triple("Face pull", "Hombros", 0), Triple("Curl con barra", "Bíceps", 0),
            Triple("Curl martillo", "Bíceps", 0), Triple("Extensión de tríceps en polea", "Tríceps", 0),
            Triple("Press francés", "Tríceps", 0), Triple("Sentadilla", "Piernas", 0),
            Triple("Prensa", "Piernas", 0), Triple("Peso muerto rumano", "Piernas", 0),
            Triple("Curl femoral", "Piernas", 0), Triple("Extensión de cuádriceps", "Piernas", 0),
            Triple("Pantorrillas de pie", "Piernas", 0), Triple("Hip thrust", "Glúteos", 0),
            Triple("Crunch en polea", "Abdomen", 0), Triple("Cinta (trote)", "Cardio", 1),
            Triple("Cinta HIIT", "Cardio", 1), Triple("Bicicleta", "Cardio", 1), Triple("Elíptica", "Cardio", 1)
        )
        ex.forEach { (n, c, t) ->
            db.insert("exercise", null, ContentValues().apply {
                put("name", n); put("category_id", catIds[c]); put("type", t); put("rest_sec", if (t == 1) 0 else 90)
            })
        }
    }
}

// ---------- Repositorio (todas las consultas) ----------

object Repo {
    private var helper: DbHelper? = null
    lateinit var appContext: Context
        private set

    /** Cada escritura incrementa este contador y las pantallas se recargan solas. */
    val changes = MutableStateFlow(0)

    fun init(ctx: Context) {
        appContext = ctx.applicationContext
        if (helper == null) helper = DbHelper(appContext)
    }

    val db: SQLiteDatabase
        get() = (helper ?: DbHelper(appContext).also { helper = it }).writableDatabase

    fun bump() = changes.update { it + 1 }

    fun closeDb() {
        helper?.close(); helper = null
    }

    fun dbFile(): File = appContext.getDatabasePath(DbHelper.NAME)

    private inline fun <T> q(sql: String, args: Array<String> = emptyArray(), map: (Cursor) -> T): List<T> {
        val out = ArrayList<T>()
        db.rawQuery(sql, args).use { c -> while (c.moveToNext()) out.add(map(c)) }
        return out
    }

    private fun Cursor.dOrNull(i: Int): Double? = if (isNull(i)) null else getDouble(i)
    private fun Cursor.lOrNull(i: Int): Long? = if (isNull(i)) null else getLong(i)

    fun <T> tx(block: () -> T): T {
        val d = db
        d.beginTransaction()
        try {
            val r = block()
            d.setTransactionSuccessful()
            return r
        } finally {
            d.endTransaction()
        }
    }

    // ----- Categorías -----
    fun categories(): List<Category> =
        q("SELECT id,name,color FROM category ORDER BY name") { Category(it.getLong(0), it.getString(1), it.getLong(2)) }

    fun addCategory(name: String): Long {
        val existing = q("SELECT id FROM category WHERE name=? COLLATE NOCASE", arrayOf(name.trim())) { it.getLong(0) }
        if (existing.isNotEmpty()) return existing[0]
        val palette = listOf(0xFFE57373, 0xFF64B5F6, 0xFFFFB74D, 0xFFBA68C8, 0xFF4DB6AC, 0xFF81C784, 0xFFF06292, 0xFFA1887F)
        val n = categories().size
        return db.insert("category", null, ContentValues().apply { put("name", name.trim()); put("color", palette[n % palette.size]) })
    }

    // ----- Ejercicios -----
    private const val EX_SELECT =
        "SELECT e.id,e.name,IFNULL(e.category_id,0),IFNULL(c.name,'Sin categoría'),e.type,e.rest_sec,IFNULL(e.notes,''),IFNULL(c.color,4288585374) " +
            "FROM exercise e LEFT JOIN category c ON c.id=e.category_id"

    private fun mapEx(c: Cursor) = Exercise(
        c.getLong(0), c.getString(1), c.getLong(2), c.getString(3), c.getInt(4), c.getInt(5), c.getString(6), c.getLong(7)
    )

    fun exercises(): List<Exercise> = q("$EX_SELECT ORDER BY c.name, e.name COLLATE NOCASE") { mapEx(it) }

    fun exercise(id: Long): Exercise? = q("$EX_SELECT WHERE e.id=?", arrayOf(id.toString())) { mapEx(it) }.firstOrNull()

    fun findExercise(name: String): Exercise? =
        q("$EX_SELECT WHERE e.name=? COLLATE NOCASE", arrayOf(name.trim())) { mapEx(it) }.firstOrNull()

    fun saveExercise(id: Long?, name: String, categoryId: Long?, type: Int, restSec: Int): Long {
        val cv = ContentValues().apply {
            put("name", name.trim()); put("category_id", categoryId); put("type", type); put("rest_sec", restSec)
        }
        return if (id == null) db.insert("exercise", null, cv)
        else { db.update("exercise", cv, "id=?", arrayOf(id.toString())); id }
    }

    fun deleteExercise(id: Long) {
        db.delete("exercise", "id=?", arrayOf(id.toString()))
    }

    // ----- Series -----
    private const val SET_SELECT = "SELECT id,date,exercise_id,ord,weight,reps,rpe,distance,duration,IFNULL(note,'') FROM workout_set"

    private fun mapSet(c: Cursor) = WorkoutSet(
        c.getLong(0), c.getString(1), c.getLong(2), c.getInt(3), c.getDouble(4), c.getInt(5),
        c.dOrNull(6), c.getDouble(7), c.getInt(8), c.getString(9)
    )

    fun setsFor(date: String): List<WorkoutSet> =
        q("$SET_SELECT WHERE date=? ORDER BY id", arrayOf(date)) { mapSet(it) }

    fun setsFor(date: String, exId: Long): List<WorkoutSet> =
        q("$SET_SELECT WHERE date=? AND exercise_id=? ORDER BY ord, id", arrayOf(date, exId.toString())) { mapSet(it) }

    fun history(exId: Long): List<WorkoutSet> =
        q("$SET_SELECT WHERE exercise_id=? ORDER BY date, ord, id", arrayOf(exId.toString())) { mapSet(it) }

    fun allSets(): List<WorkoutSet> = q("$SET_SELECT ORDER BY date, exercise_id, ord, id") { mapSet(it) }

    fun addSet(
        date: String, exId: Long, weight: Double, reps: Int, rpe: Double?,
        distance: Double, durationSec: Int, note: String
    ): Long {
        val ord = q("SELECT IFNULL(MAX(ord),0) FROM workout_set WHERE date=? AND exercise_id=?", arrayOf(date, exId.toString())) { it.getInt(0) }.first() + 1
        return db.insert("workout_set", null, ContentValues().apply {
            put("date", date); put("exercise_id", exId); put("ord", ord); put("weight", weight); put("reps", reps)
            put("rpe", rpe); put("distance", distance); put("duration", durationSec); put("note", note)
        })
    }

    fun updateSet(s: WorkoutSet) {
        db.update("workout_set", ContentValues().apply {
            put("weight", s.weight); put("reps", s.reps); put("rpe", s.rpe); put("distance", s.distance)
            put("duration", s.durationSec); put("note", s.note)
        }, "id=?", arrayOf(s.id.toString()))
    }

    fun deleteSet(id: Long) {
        db.delete("workout_set", "id=?", arrayOf(id.toString()))
    }

    fun lastSession(exId: Long, beforeDate: String): Pair<String, List<WorkoutSet>>? {
        val d = q("SELECT MAX(date) FROM workout_set WHERE exercise_id=? AND date<?", arrayOf(exId.toString(), beforeDate)) {
            if (it.isNull(0)) null else it.getString(0)
        }.firstOrNull() ?: return null
        return d to setsFor(d, exId)
    }

    fun bestE1rmBefore(exId: Long, date: String): Double =
        q("SELECT weight,reps FROM workout_set WHERE exercise_id=? AND date<?", arrayOf(exId.toString(), date)) {
            Stats.e1rm(it.getDouble(0), it.getInt(1))
        }.maxOrNull() ?: 0.0

    fun workoutDates(): List<String> = q("SELECT DISTINCT date FROM workout_set ORDER BY date") { it.getString(0) }

    fun statRows(fromDate: String): List<StatRow> = q(
        "SELECT s.date,s.exercise_id,e.name,IFNULL(c.name,'Sin categoría'),IFNULL(c.color,4288585374),e.type,s.weight,s.reps " +
            "FROM workout_set s JOIN exercise e ON e.id=s.exercise_id LEFT JOIN category c ON c.id=e.category_id " +
            "WHERE s.date>=? ORDER BY s.date, s.ord", arrayOf(fromDate)
    ) { StatRow(it.getString(0), it.getLong(1), it.getString(2), it.getString(3), it.getLong(4), it.getInt(5), it.getDouble(6), it.getInt(7)) }

    /** Ejercicios con historial y cantidad de sesiones. */
    fun exercisesWithHistory(): List<Pair<Exercise, Int>> {
        val counts = q("SELECT exercise_id, COUNT(DISTINCT date) FROM workout_set GROUP BY exercise_id") { it.getLong(0) to it.getInt(1) }.toMap()
        return exercises().filter { counts.containsKey(it.id) }.map { it to counts.getValue(it.id) }
    }

    // ----- Día de entrenamiento (plan + series) -----
    fun dayExercises(date: String): List<DayExercise> {
        val exMap = exercises().associateBy { it.id }
        val sets = setsFor(date)
        val plan = q("SELECT exercise_id,item_id FROM day_plan WHERE date=? ORDER BY ord, id", arrayOf(date)) { it.getLong(0) to it.lOrNull(1) }
        val order = LinkedHashSet<Long>()
        plan.forEach { order.add(it.first) }
        sets.forEach { order.add(it.exerciseId) }
        val itemByEx = plan.associate { it.first to it.second }
        return order.mapNotNull { id ->
            val ex = exMap[id] ?: return@mapNotNull null
            DayExercise(ex, sets.filter { it.exerciseId == id }.sortedBy { it.order }, itemByEx[id]?.let { routineItem(it) })
        }
    }

    fun addToPlan(date: String, exId: Long, itemId: Long?) {
        val exists = q("SELECT id FROM day_plan WHERE date=? AND exercise_id=?", arrayOf(date, exId.toString())) { it.getLong(0) }
        if (exists.isNotEmpty()) {
            if (itemId != null) db.update("day_plan", ContentValues().apply { put("item_id", itemId) }, "id=?", arrayOf(exists[0].toString()))
            return
        }
        val ord = q("SELECT IFNULL(MAX(ord),0) FROM day_plan WHERE date=?", arrayOf(date)) { it.getInt(0) }.first() + 1
        db.insert("day_plan", null, ContentValues().apply {
            put("date", date); put("exercise_id", exId); put("item_id", itemId); put("ord", ord)
        })
    }

    fun startDay(date: String, dayId: Long) = tx {
        routineItems(dayId).forEach { addToPlan(date, it.exerciseId, it.id) }
    }

    fun removeFromDay(date: String, exId: Long) = tx {
        db.delete("workout_set", "date=? AND exercise_id=?", arrayOf(date, exId.toString()))
        db.delete("day_plan", "date=? AND exercise_id=?", arrayOf(date, exId.toString()))
    }

    fun planItem(date: String, exId: Long): RoutineItem? =
        q("SELECT item_id FROM day_plan WHERE date=? AND exercise_id=?", arrayOf(date, exId.toString())) { it.lOrNull(0) }
            .firstOrNull()?.let { routineItem(it) }

    // ----- Rutinas -----
    fun routines(): List<Routine> = q("SELECT id,name FROM routine ORDER BY name") { Routine(it.getLong(0), it.getString(1)) }

    fun routine(id: Long): Routine? = q("SELECT id,name FROM routine WHERE id=?", arrayOf(id.toString())) { Routine(it.getLong(0), it.getString(1)) }.firstOrNull()

    fun addRoutine(name: String): Long = db.insert("routine", null, ContentValues().apply { put("name", name.trim()) })

    fun renameRoutine(id: Long, name: String) {
        db.update("routine", ContentValues().apply { put("name", name.trim()) }, "id=?", arrayOf(id.toString()))
    }

    fun deleteRoutine(id: Long) {
        db.delete("routine", "id=?", arrayOf(id.toString()))
    }

    fun routineDays(routineId: Long): List<RoutineDay> =
        q("SELECT id,routine_id,name,ord FROM routine_day WHERE routine_id=? ORDER BY ord, id", arrayOf(routineId.toString())) {
            RoutineDay(it.getLong(0), it.getLong(1), it.getString(2), it.getInt(3))
        }

    /** Todos los días de todas las rutinas: (día, nombre de rutina). */
    fun allRoutineDays(): List<Pair<RoutineDay, String>> =
        q("SELECT d.id,d.routine_id,d.name,d.ord,r.name FROM routine_day d JOIN routine r ON r.id=d.routine_id ORDER BY r.name, d.ord, d.id") {
            RoutineDay(it.getLong(0), it.getLong(1), it.getString(2), it.getInt(3)) to it.getString(4)
        }

    fun addDay(routineId: Long, name: String): Long {
        val ord = q("SELECT IFNULL(MAX(ord),0) FROM routine_day WHERE routine_id=?", arrayOf(routineId.toString())) { it.getInt(0) }.first() + 1
        return db.insert("routine_day", null, ContentValues().apply { put("routine_id", routineId); put("name", name.trim()); put("ord", ord) })
    }

    fun renameDay(id: Long, name: String) {
        db.update("routine_day", ContentValues().apply { put("name", name.trim()) }, "id=?", arrayOf(id.toString()))
    }

    fun deleteDay(id: Long) {
        db.delete("routine_day", "id=?", arrayOf(id.toString()))
    }

    private const val ITEM_SELECT =
        "SELECT i.id,i.day_id,i.exercise_id,e.name,i.ord,i.sets,i.rep_min,i.rep_max,i.increment FROM routine_item i JOIN exercise e ON e.id=i.exercise_id"

    private fun mapItem(c: Cursor) = RoutineItem(
        c.getLong(0), c.getLong(1), c.getLong(2), c.getString(3), c.getInt(4), c.getInt(5), c.getInt(6), c.getInt(7), c.getDouble(8)
    )

    fun routineItems(dayId: Long): List<RoutineItem> =
        q("$ITEM_SELECT WHERE i.day_id=? ORDER BY i.ord, i.id", arrayOf(dayId.toString())) { mapItem(it) }

    fun routineItem(id: Long): RoutineItem? = q("$ITEM_SELECT WHERE i.id=?", arrayOf(id.toString())) { mapItem(it) }.firstOrNull()

    fun addItem(dayId: Long, exId: Long): Long {
        val ord = q("SELECT IFNULL(MAX(ord),0) FROM routine_item WHERE day_id=?", arrayOf(dayId.toString())) { it.getInt(0) }.first() + 1
        return db.insert("routine_item", null, ContentValues().apply {
            put("day_id", dayId); put("exercise_id", exId); put("ord", ord)
            put("sets", 3); put("rep_min", 8); put("rep_max", 12); put("increment", 2.5)
        })
    }

    fun updateItem(it: RoutineItem) {
        db.update("routine_item", ContentValues().apply {
            put("sets", it.sets); put("rep_min", it.repMin); put("rep_max", it.repMax); put("increment", it.increment)
        }, "id=?", arrayOf(it.id.toString()))
    }

    fun deleteItem(id: Long) {
        db.delete("routine_item", "id=?", arrayOf(id.toString()))
    }

    /** Mueve un ejercicio de la rutina hacia arriba (-1) o abajo (+1). */
    fun moveItem(item: RoutineItem, dir: Int) = tx {
        val list = routineItems(item.dayId).toMutableList()
        val i = list.indexOfFirst { it.id == item.id }
        val j = i + dir
        if (i < 0 || j !in list.indices) return@tx
        val tmp = list[i]; list[i] = list[j]; list[j] = tmp
        list.forEachIndexed { idx, ri ->
            db.update("routine_item", ContentValues().apply { put("ord", idx + 1) }, "id=?", arrayOf(ri.id.toString()))
        }
    }

    // ----- Cuerpo -----
    fun bodyEntries(): List<BodyEntry> =
        q("SELECT id,date,weight,body_fat,waist,IFNULL(note,'') FROM body ORDER BY date, id") {
            BodyEntry(it.getLong(0), it.getString(1), it.dOrNull(2), it.dOrNull(3), it.dOrNull(4), it.getString(5))
        }

    fun addBody(date: String, weight: Double?, fat: Double?, waist: Double?, note: String) {
        db.insert("body", null, ContentValues().apply {
            put("date", date); put("weight", weight); put("body_fat", fat); put("waist", waist); put("note", note)
        })
    }

    fun deleteBody(id: Long) {
        db.delete("body", "id=?", arrayOf(id.toString()))
    }
}
