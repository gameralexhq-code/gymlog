package cl.alex.gymlog.ui

import android.app.DatePickerDialog
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cl.alex.gymlog.data.Repo
import cl.alex.gymlog.data.fmtTime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

// ---------- Tema ----------

private val Accent = Color(0xFFFFB74D)

@Composable
fun GymTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Accent,
        onPrimary = Color(0xFF2B1700),
        primaryContainer = Color(0xFF4A3410),
        onPrimaryContainer = Color(0xFFFFDDB3),
        secondary = Color(0xFF64B5F6),
        background = Color(0xFF121417),
        surface = Color(0xFF121417),
        surfaceVariant = Color(0xFF22262B),
        surfaceContainer = Color(0xFF1B1E22),
        surfaceContainerHigh = Color(0xFF22262B)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

// ---------- Carga de datos ----------

/** Ejecuta [block] en segundo plano y vuelve a ejecutarlo cada vez que cambia la base de datos o las [keys]. */
@Composable
fun <T> load(initial: T, vararg keys: Any?, block: () -> T): State<T> {
    val version by Repo.changes.collectAsState()
    val allKeys: Array<Any?> = arrayOf<Any?>(version) + keys
    return produceState(initial, *allKeys) {
        value = withContext(Dispatchers.IO) { block() }
    }
}

/** Escribe en la base de datos en segundo plano y avisa a las pantallas. */
fun CoroutineScope.write(after: (() -> Unit)? = null, block: () -> Unit) {
    launch {
        withContext(Dispatchers.IO) { block() }
        Repo.bump()
        after?.invoke()
    }
}

// ---------- Fechas ----------

private val esLocale: Locale = Locale.forLanguageTag("es-CL")

fun prettyDate(d: LocalDate): String =
    d.format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM yyyy", esLocale)).replaceFirstChar { it.uppercase() }

fun shortDate(s: String): String = try {
    LocalDate.parse(s).format(DateTimeFormatter.ofPattern("d MMM yy", esLocale))
} catch (e: Exception) { s }

fun pickDate(ctx: Context, current: LocalDate, onPick: (LocalDate) -> Unit) {
    DatePickerDialog(ctx, { _, y, m, d -> onPick(LocalDate.of(y, m + 1, d)) }, current.year, current.monthValue - 1, current.dayOfMonth).show()
}

// ---------- Componentes ----------

@Composable
fun Screen(
    title: String,
    nav: NavController? = null,
    actions: @Composable RowScope.() -> Unit = {},
    fab: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1) },
                navigationIcon = {
                    if (nav != null) IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver")
                    }
                },
                actions = actions
            )
        },
        floatingActionButton = fab,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { pad -> content(pad) }
}

@Composable
fun ColorDot(color: Long, size: Int = 10) {
    Box(Modifier.size(size.dp).background(Color(color), CircleShape))
}

@Composable
fun NumField(
    value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, decimal: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = if (decimal) KeyboardType.Decimal else KeyboardType.Number),
        modifier = modifier
    )
}

@Composable
fun TextDialog(title: String, initial: String = "", label: String = "Nombre", onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, label = { Text(label) }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (text.isNotBlank()) onOk(text.trim()) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun ConfirmDialog(title: String, text: String, onDismiss: () -> Unit, onOk: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onOk) { Text("Sí, borrar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = modifier.padding(vertical = 8.dp))
}

// ---------- Gráfico de línea ----------

@Composable
fun LineChart(
    values: List<Double>,
    labels: List<String>,
    unit: String,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary
) {
    if (values.size < 2) {
        Text("Se necesitan al menos 2 registros para graficar.", style = MaterialTheme.typography.bodySmall, modifier = modifier.padding(8.dp))
        return
    }
    val min = values.min()
    val max = values.max()
    val grid = MaterialTheme.colorScheme.outlineVariant
    Column(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("máx ${cl.alex.gymlog.data.fmt(max)} $unit", style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.weight(1f))
            Text("último ${cl.alex.gymlog.data.fmt(values.last())} $unit", style = MaterialTheme.typography.labelSmall, color = color)
        }
        Canvas(Modifier.fillMaxWidth().height(180.dp).padding(vertical = 8.dp)) {
            val range = (max - min).takeIf { it > 1e-9 } ?: 1.0
            val stepX = size.width / (values.size - 1)
            fun y(v: Double) = (size.height - ((v - min) / range * size.height)).toFloat()
            for (g in 0..3) {
                val gy = size.height * g / 3f
                drawLine(grid, Offset(0f, gy), Offset(size.width, gy), strokeWidth = 1f)
            }
            for (i in 1 until values.size) {
                drawLine(color, Offset(stepX * (i - 1), y(values[i - 1])), Offset(stepX * i, y(values[i])), strokeWidth = 5f)
            }
            if (values.size <= 60) values.forEachIndexed { i, v ->
                drawCircle(color, radius = 6f, center = Offset(stepX * i, y(v)))
                drawCircle(Color(0xFF121417), radius = 3f, center = Offset(stepX * i, y(v)), style = Stroke(2f))
            }
        }
        Row {
            Text(labels.firstOrNull() ?: "", style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.weight(1f))
            Text("mín ${cl.alex.gymlog.data.fmt(min)} $unit", style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.weight(1f))
            Text(labels.lastOrNull() ?: "", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun HBar(label: String, fraction: Float, color: Color, trailing: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(92.dp), maxLines = 1)
        Box(Modifier.weight(1f).height(14.dp).background(MaterialTheme.colorScheme.surfaceVariant)) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(fraction.coerceIn(0f, 1f)).background(color))
        }
        Text(trailing, style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(72.dp).padding(start = 6.dp))
    }
}

// ---------- Timer de descanso ----------

object RestTimer {
    val endAt = MutableStateFlow(0L)
    val total = MutableStateFlow(0)

    fun start(sec: Int) {
        if (sec <= 0) return
        total.value = sec
        endAt.value = System.currentTimeMillis() + sec * 1000L
    }

    fun add(sec: Int) {
        if (endAt.value > 0) {
            endAt.value = maxOf(System.currentTimeMillis() + 1000, endAt.value + sec * 1000L)
            total.value = maxOf(total.value + sec, 1)
        }
    }

    fun stop() {
        endAt.value = 0L
    }
}

@Suppress("DEPRECATION")
private fun alarm(ctx: Context) {
    try {
        val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400, 200, 600), -1))
    } catch (e: Exception) { }
    try {
        ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90).startTone(ToneGenerator.TONE_PROP_BEEP2, 600)
    } catch (e: Exception) { }
}

@Composable
fun RestTimerBar() {
    val end by RestTimer.endAt.collectAsState()
    val total by RestTimer.total.collectAsState()
    if (end == 0L) return
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(end) {
        while (true) {
            now = System.currentTimeMillis()
            if (now >= end) {
                alarm(ctx)
                RestTimer.stop()
                break
            }
            delay(250)
        }
    }
    val remaining = ((end - now + 999) / 1000).toInt().coerceAtLeast(0)
    Surface(color = MaterialTheme.colorScheme.primaryContainer) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Timer, null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                Text(
                    "  Descanso ${fmtTime(remaining)}",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { RestTimer.add(-15) }) { Text("-15s") }
                TextButton(onClick = { RestTimer.add(15) }) { Text("+15s") }
                IconButton(onClick = { RestTimer.stop() }) { Icon(Icons.Filled.Close, "Detener") }
            }
            LinearProgressIndicator(
                progress = { if (total > 0) remaining / total.toFloat() else 0f },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
