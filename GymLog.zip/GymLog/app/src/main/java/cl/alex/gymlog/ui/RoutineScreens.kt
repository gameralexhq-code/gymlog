package cl.alex.gymlog.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cl.alex.gymlog.data.*

@Composable
fun RoutinesScreen(nav: NavController) {
    val scope = rememberCoroutineScope()
    val data by load(emptyList<Pair<Routine, List<RoutineDay>>>()) {
        Repo.routines().map { it to Repo.routineDays(it.id) }
    }
    var adding by remember { mutableStateOf(false) }
    Screen(
        "Rutinas",
        fab = { FloatingActionButton(onClick = { adding = true }) { Icon(Icons.Filled.Add, "Nueva rutina") } }
    ) { pad ->
        if (data.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    "Crea tu primera rutina (ej. \"Push Pull Legs\") y agrégale días con sus ejercicios, series y rango de reps.\n\n" +
                        "Cuando completes todas las series en el tope del rango, la app te sugerirá subir el peso.",
                    textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(data, key = { it.first.id }) { (r, days) ->
                    Card(Modifier.fillMaxWidth().clickable { nav.navigate("routine/${r.id}") }) {
                        Column(Modifier.padding(16.dp)) {
                            Text(r.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (days.isEmpty()) "Sin días" else days.joinToString(" · ") { it.name },
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
    if (adding) {
        TextDialog("Nueva rutina", onDismiss = { adding = false }) { name ->
            adding = false
            var id = 0L
            scope.write(after = { nav.navigate("routine/$id") }) { id = Repo.addRoutine(name) }
        }
    }
}

private data class DayWithItems(val day: RoutineDay, val items: List<RoutineItem>)

@Composable
fun RoutineEditScreen(id: Long, nav: NavController) {
    val scope = rememberCoroutineScope()
    val routine by load<Routine?>(null, id) { Repo.routine(id) }
    val days by load(emptyList<DayWithItems>(), id) { Repo.routineDays(id).map { DayWithItems(it, Repo.routineItems(it.id)) } }
    var addDay by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var deleteRoutine by remember { mutableStateOf(false) }
    var pickFor by remember { mutableStateOf<RoutineDay?>(null) }
    var editItem by remember { mutableStateOf<RoutineItem?>(null) }
    var dayMenu by remember { mutableStateOf<RoutineDay?>(null) }
    var renameDay by remember { mutableStateOf<RoutineDay?>(null) }

    Screen(
        routine?.name ?: "Rutina", nav,
        actions = {
            IconButton(onClick = { rename = true }) { Icon(Icons.Filled.Edit, "Renombrar") }
            IconButton(onClick = { deleteRoutine = true }) { Icon(Icons.Filled.Delete, "Borrar rutina") }
        },
        fab = { ExtendedFloatingActionButton(onClick = { addDay = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Día") }) }
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 88.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (days.isEmpty()) item {
                Text("Agrega días (ej. \"Día A - Pecho/Tríceps\") con el botón + Día.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(days, key = { it.day.id }) { dw ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(vertical = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 16.dp)) {
                            Text(dw.day.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            IconButton(onClick = { pickFor = dw.day }) { Icon(Icons.Filled.Add, "Agregar ejercicio") }
                            Box {
                                IconButton(onClick = { dayMenu = dw.day }) { Icon(Icons.Filled.MoreVert, "Opciones") }
                                DropdownMenu(expanded = dayMenu?.id == dw.day.id, onDismissRequest = { dayMenu = null }) {
                                    DropdownMenuItem(text = { Text("Renombrar día") }, onClick = { renameDay = dw.day; dayMenu = null })
                                    DropdownMenuItem(text = { Text("Borrar día") }, onClick = {
                                        val d = dw.day; dayMenu = null
                                        scope.write { Repo.deleteDay(d.id) }
                                    })
                                }
                            }
                        }
                        if (dw.items.isEmpty()) {
                            Text("Sin ejercicios — toca +", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp))
                        }
                        dw.items.forEach { it ->
                            ListItem(
                                headlineContent = { Text(it.exerciseName) },
                                supportingContent = { Text("${it.sets} series × ${it.repMin}-${it.repMax} reps · +${fmt(it.increment)} kg al progresar") },
                                modifier = Modifier.clickable { editItem = it },
                                colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
                            )
                        }
                    }
                }
            }
        }
    }

    if (addDay) TextDialog("Nuevo día", onDismiss = { addDay = false }) { n ->
        addDay = false; scope.write { Repo.addDay(id, n) }
    }
    if (rename) TextDialog("Renombrar rutina", routine?.name ?: "", onDismiss = { rename = false }) { n ->
        rename = false; scope.write { Repo.renameRoutine(id, n) }
    }
    renameDay?.let { d ->
        TextDialog("Renombrar día", d.name, onDismiss = { renameDay = null }) { n ->
            renameDay = null; scope.write { Repo.renameDay(d.id, n) }
        }
    }
    if (deleteRoutine) ConfirmDialog("Borrar rutina", "Se borrará la rutina y sus días. Tu historial de entrenamientos NO se borra.", { deleteRoutine = false }) {
        deleteRoutine = false
        scope.write(after = { nav.popBackStack() }) { Repo.deleteRoutine(id) }
    }
    pickFor?.let { day ->
        PickExerciseDialog(onDismiss = { pickFor = null }) { exId ->
            pickFor = null; scope.write { Repo.addItem(day.id, exId) }
        }
    }
    editItem?.let { item -> ItemDialog(item, onDismiss = { editItem = null }) }
}

@Composable
private fun ItemDialog(item: RoutineItem, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var sets by remember { mutableStateOf(item.sets.toString()) }
    var min by remember { mutableStateOf(item.repMin.toString()) }
    var max by remember { mutableStateOf(item.repMax.toString()) }
    var inc by remember { mutableStateOf(fmt(item.increment)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(item.exerciseName) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField(sets, { sets = it }, "Series", decimal = false)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField(min, { min = it }, "Reps mín", Modifier.weight(1f), decimal = false)
                    NumField(max, { max = it }, "Reps máx", Modifier.weight(1f), decimal = false)
                }
                NumField(inc, { inc = it }, "Aumento de peso (kg)")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { scope.write { Repo.moveItem(item, -1) } }) { Icon(Icons.Filled.KeyboardArrowUp, null); Text("Subir") }
                    OutlinedButton(onClick = { scope.write { Repo.moveItem(item, 1) } }) { Icon(Icons.Filled.KeyboardArrowDown, null); Text("Bajar") }
                }
                TextButton(onClick = { scope.write(after = onDismiss) { Repo.deleteItem(item.id) } }) {
                    Text("Quitar de la rutina", color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val s = sets.toIntOrNull()?.coerceIn(1, 20) ?: item.sets
                val a = min.toIntOrNull()?.coerceAtLeast(1) ?: item.repMin
                val b = (max.toIntOrNull() ?: item.repMax).coerceAtLeast(a)
                val i = parseNum(inc) ?: item.increment
                scope.write(after = onDismiss) { Repo.updateItem(item.copy(sets = s, repMin = a, repMax = b, increment = i)) }
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun PickExerciseDialog(onDismiss: () -> Unit, onPick: (Long) -> Unit) {
    val list by load(emptyList<Exercise>()) { Repo.exercises() }
    var query by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Agregar ejercicio") },
        text = {
            Column {
                OutlinedTextField(query, { query = it }, label = { Text("Buscar") }, singleLine = true)
                val q = Importer.norm(query)
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(list.filter { q.isEmpty() || Importer.norm(it.name).contains(q) || Importer.norm(it.categoryName).contains(q) }, key = { it.id }) { ex ->
                        ListItem(
                            headlineContent = { Text(ex.name) },
                            supportingContent = { Text(ex.categoryName) },
                            leadingContent = { ColorDot(ex.color, 12) },
                            modifier = Modifier.clickable { onPick(ex.id) }
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}
