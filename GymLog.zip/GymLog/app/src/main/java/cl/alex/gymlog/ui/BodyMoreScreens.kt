package cl.alex.gymlog.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cl.alex.gymlog.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

// =====================================================================
// Cuerpo: peso, % grasa, cintura
// =====================================================================

@Composable
fun BodyScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val entries by load(emptyList<BodyEntry>()) { Repo.bodyEntries() }
    var date by rememberSaveable { mutableStateOf(LocalDate.now().toString()) }
    var weight by rememberSaveable { mutableStateOf("") }
    var fat by rememberSaveable { mutableStateOf("") }
    var waist by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    var chart by rememberSaveable { mutableIntStateOf(0) }
    var toDelete by remember { mutableStateOf<BodyEntry?>(null) }

    Screen("Cuerpo") { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Card {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { pickDate(ctx, LocalDate.parse(date)) { date = it.toString() } }) {
                            Icon(Icons.Filled.CalendarMonth, null); Text("  " + prettyDate(LocalDate.parse(date)))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NumField(weight, { weight = it }, "Peso (kg)", Modifier.weight(1f))
                            NumField(fat, { fat = it }, "% grasa", Modifier.weight(1f))
                            NumField(waist, { waist = it }, "Cintura (cm)", Modifier.weight(1f))
                        }
                        OutlinedTextField(note, { note = it }, label = { Text("Nota") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            val w = parseNum(weight); val f = parseNum(fat); val c = parseNum(waist)
                            if (w == null && f == null && c == null) {
                                Toast.makeText(ctx, "Ingresa al menos un valor", Toast.LENGTH_SHORT).show()
                            } else {
                                val d = date; val n = note.trim()
                                scope.write { Repo.addBody(d, w, f, c, n) }
                                weight = ""; fat = ""; waist = ""; note = ""
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Guardar medición") }
                    }
                }
            }
            item {
                val labels = listOf("Peso", "% grasa", "Cintura")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    labels.forEachIndexed { i, l -> FilterChip(chart == i, { chart = i }, { Text(l) }) }
                }
                val pts = entries.mapNotNull { e ->
                    val v = when (chart) { 0 -> e.weight; 1 -> e.bodyFat; else -> e.waist }
                    v?.let { e.date to it }
                }
                LineChart(pts.map { it.second }, pts.map { shortDate(it.first) }, listOf("kg", "%", "cm")[chart])
                if (pts.size >= 2) {
                    val cutoff = LocalDate.now().minusDays(30).toString()
                    val ref = pts.firstOrNull { it.first >= cutoff } ?: pts.first()
                    val diff = pts.last().second - ref.second
                    Text(
                        "Cambio desde ${shortDate(ref.first)}: ${if (diff > 0) "+" else ""}${fmt(Math.round(diff * 10) / 10.0)} ${listOf("kg", "%", "cm")[chart]}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            item { SectionTitle("Registros") }
            items(entries.reversed(), key = { it.id }) { e ->
                ListItem(
                    headlineContent = {
                        Text(listOfNotNull(
                            e.weight?.let { "${fmt(it)} kg" }, e.bodyFat?.let { "${fmt(it)} %" }, e.waist?.let { "${fmt(it)} cm" }
                        ).joinToString(" · "))
                    },
                    supportingContent = { Text(shortDate(e.date) + if (e.note.isNotBlank()) " · ${e.note}" else "") },
                    trailingContent = { IconButton(onClick = { toDelete = e }) { Icon(Icons.Filled.Delete, "Borrar") } }
                )
            }
        }
    }
    toDelete?.let { e ->
        ConfirmDialog("Borrar registro", "¿Borrar la medición del ${shortDate(e.date)}?", { toDelete = null }) {
            toDelete = null; scope.write { Repo.deleteBody(e.id) }
        }
    }
}

// =====================================================================
// Más: ejercicios, importar, exportar, respaldo
// =====================================================================

@Composable
fun MoreScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }
    var confirmRestore by remember { mutableStateOf<android.net.Uri?>(null) }

    fun runTask(task: () -> String) {
        busy = true
        scope.launch {
            val msg = try {
                withContext(Dispatchers.IO) { task() }
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
            Repo.bump()
            busy = false
            result = msg
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runTask { Importer.import(ctx, uri).message }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) runTask { "Exportadas ${Exporter.exportCsv(ctx, uri)} series." }
    }
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) runTask { Exporter.backupDb(ctx, uri); "Respaldo guardado. Guárdalo en Drive o en tu PC." }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) confirmRestore = uri
    }

    Screen("Más") { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            MoreItem(Icons.Filled.FitnessCenter, "Ejercicios", "Crear, editar, grupo muscular y tiempo de descanso") { nav.navigate("exercises") }
            HorizontalDivider()
            MoreItem(Icons.Filled.UploadFile, "Importar CSV / Excel", "Backup de FitNotes o tus planillas (.csv, .xlsx)") {
                importLauncher.launch(arrayOf("*/*"))
            }
            MoreItem(Icons.Filled.Download, "Exportar CSV", "Formato compatible con FitNotes / Excel") {
                exportLauncher.launch("gymlog_${LocalDate.now()}.csv")
            }
            HorizontalDivider()
            MoreItem(Icons.Filled.Save, "Respaldo completo (.db)", "Todo: series, rutinas, cuerpo, ejercicios") {
                backupLauncher.launch("gymlog_respaldo_${LocalDate.now()}.db")
            }
            MoreItem(Icons.Filled.Restore, "Restaurar respaldo", "Reemplaza todos los datos actuales") {
                restoreLauncher.launch(arrayOf("*/*"))
            }
            Spacer(Modifier.weight(1f))
            Text(
                "GymLog 1.0 · Tus datos se guardan solo en este teléfono. Haz respaldos de vez en cuando.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(16.dp)
            )
        }
    }

    result?.let { msg ->
        AlertDialog(
            onDismissRequest = { result = null },
            title = { Text("Listo") },
            text = { Text(msg) },
            confirmButton = { TextButton(onClick = { result = null }) { Text("OK") } }
        )
    }
    confirmRestore?.let { uri ->
        AlertDialog(
            onDismissRequest = { confirmRestore = null },
            title = { Text("Restaurar respaldo") },
            text = { Text("Se reemplazarán TODOS los datos actuales por los del respaldo. ¿Continuar?") },
            confirmButton = {
                TextButton(onClick = {
                    confirmRestore = null
                    runTask { Exporter.restoreDb(ctx, uri); "Respaldo restaurado." }
                }) { Text("Restaurar") }
            },
            dismissButton = { TextButton(onClick = { confirmRestore = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun MoreItem(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(sub) },
        leadingContent = { Icon(icon, null) },
        modifier = Modifier.clickable(onClick = onClick)
    )
}

// =====================================================================
// Gestión de ejercicios
// =====================================================================

@Composable
fun ExercisesScreen(nav: NavController) {
    val scope = rememberCoroutineScope()
    val list by load(emptyList<Exercise>()) { Repo.exercises() }
    var query by rememberSaveable { mutableStateOf("") }
    var editing by remember { mutableStateOf<Exercise?>(null) }
    var creating by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Exercise?>(null) }
    Screen("Ejercicios", nav, fab = {
        FloatingActionButton(onClick = { creating = true }) { Icon(Icons.Filled.Add, "Nuevo") }
    }) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(query, { query = it }, label = { Text("Buscar") }, singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Search, null) }, modifier = Modifier.fillMaxWidth().padding(12.dp))
            val q = Importer.norm(query)
            LazyColumn(contentPadding = PaddingValues(bottom = 88.dp)) {
                items(list.filter { q.isEmpty() || Importer.norm(it.name).contains(q) || Importer.norm(it.categoryName).contains(q) }, key = { it.id }) { ex ->
                    ListItem(
                        headlineContent = { Text(ex.name) },
                        supportingContent = {
                            Text(ex.categoryName + " · " + (if (ex.type == TYPE_CARDIO) "Cardio" else "Fuerza") +
                                if (ex.restSec > 0) " · descanso ${fmtTime(ex.restSec)}" else "")
                        },
                        leadingContent = { ColorDot(ex.color, 12) },
                        trailingContent = { IconButton(onClick = { toDelete = ex }) { Icon(Icons.Filled.Delete, "Borrar") } },
                        modifier = Modifier.clickable { editing = ex }
                    )
                }
            }
        }
    }
    if (creating) ExerciseDialog(null, onDismiss = { creating = false }) { creating = false }
    editing?.let { ex -> ExerciseDialog(ex, onDismiss = { editing = null }) { editing = null } }
    toDelete?.let { ex ->
        ConfirmDialog("Borrar ${ex.name}", "Se borrará el ejercicio y TODO su historial de series. No se puede deshacer.", { toDelete = null }) {
            toDelete = null; scope.write { Repo.deleteExercise(ex.id) }
        }
    }
}
