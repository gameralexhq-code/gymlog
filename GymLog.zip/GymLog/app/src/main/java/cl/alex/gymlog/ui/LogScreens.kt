package cl.alex.gymlog.ui

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cl.alex.gymlog.data.*
import java.time.LocalDate

// =====================================================================
// Pantalla principal: entrenamiento del día
// =====================================================================

@Composable
fun LogScreen(date: String, onDate: (String) -> Unit, nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val day by load(emptyList<DayExercise>(), date) { Repo.dayExercises(date) }
    val routineDays by load(emptyList<Pair<RoutineDay, String>>()) { Repo.allRoutineDays() }
    var showStart by remember { mutableStateOf(false) }
    val d = LocalDate.parse(date)
    val today = LocalDate.now()

    Screen(
        title = "Entrenamiento",
        fab = {
            FloatingActionButton(onClick = { nav.navigate("pick/$date") }) { Icon(Icons.Filled.Add, "Agregar ejercicio") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                IconButton(onClick = { onDate(d.minusDays(1).toString()) }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Día anterior")
                }
                Text(
                    prettyDate(d),
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f).clickable { pickDate(ctx, d) { onDate(it.toString()) } }
                )
                IconButton(onClick = { onDate(d.plusDays(1).toString()) }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Día siguiente")
                }
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(horizontal = 12.dp)
            ) {
                OutlinedButton(onClick = {
                    if (routineDays.isEmpty()) Toast.makeText(ctx, "Primero crea una rutina en la pestaña Rutinas", Toast.LENGTH_LONG).show()
                    else showStart = true
                }) {
                    Icon(Icons.Filled.PlayArrow, null); Text(" Iniciar rutina")
                }
                if (d != today) TextButton(onClick = { onDate(today.toString()) }) { Text("Ir a hoy") }
            }
            val allSets = day.flatMap { it.sets }
            if (allSets.isNotEmpty()) {
                val vol = allSets.sumOf { it.weight * it.reps }
                Text(
                    "${day.size} ejercicios · ${allSets.size} series · ${fmt(vol)} kg de volumen",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }
            if (day.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Sin entrenamiento registrado.\nToca + para agregar un ejercicio o inicia una rutina.",
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(12.dp, 4.dp, 12.dp, 88.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(day, key = { it.exercise.id }) { de ->
                        DayExerciseCard(de) { nav.navigate("exlog/${de.exercise.id}/$date") }
                    }
                }
            }
        }
    }

    if (showStart) {
        AlertDialog(
            onDismissRequest = { showStart = false },
            title = { Text("¿Qué día de rutina?") },
            text = {
                LazyColumn(Modifier.heightIn(max = 400.dp)) {
                    items(routineDays, key = { it.first.id }) { (rd, rName) ->
                        ListItem(
                            headlineContent = { Text(rd.name) },
                            supportingContent = { Text(rName) },
                            modifier = Modifier.clickable {
                                showStart = false
                                scope.write { Repo.startDay(date, rd.id) }
                            }
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showStart = false }) { Text("Cerrar") } }
        )
    }
}

@Composable
private fun DayExerciseCard(de: DayExercise, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ColorDot(de.exercise.color)
                Text("  " + de.exercise.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                de.item?.let {
                    val done = de.sets.size
                    Text("$done/${it.sets}", style = MaterialTheme.typography.labelLarge,
                        color = if (done >= it.sets) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (de.sets.isEmpty()) {
                val target = de.item?.let { " · objetivo ${it.sets}×${it.repMin}-${it.repMax}" } ?: ""
                Text("Pendiente$target", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    de.sets.forEach { s ->
                        Text(setLabel(s, de.exercise.type), style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(top = 4.dp))
                        if (s != de.sets.last()) Text("·", modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
    }
}

// =====================================================================
// Selector de ejercicio
// =====================================================================

@Composable
fun ExercisePickerScreen(date: String, nav: NavController) {
    val scope = rememberCoroutineScope()
    val list by load(emptyList<Exercise>()) { Repo.exercises() }
    var query by rememberSaveable { mutableStateOf("") }
    var creating by remember { mutableStateOf(false) }
    fun open(id: Long) {
        scope.write(after = {
            nav.popBackStack()
            nav.navigate("exlog/$id/$date")
        }) { Repo.addToPlan(date, id, null) }
    }
    Screen("Elegir ejercicio", nav) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            OutlinedTextField(
                query, { query = it }, label = { Text("Buscar") }, singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            )
            val q = Importer.norm(query)
            val filtered = list.filter { q.isEmpty() || Importer.norm(it.name).contains(q) || Importer.norm(it.categoryName).contains(q) }
            LazyColumn(Modifier.weight(1f)) {
                item {
                    ListItem(
                        headlineContent = { Text(if (query.isBlank()) "Crear ejercicio nuevo" else "Crear \"$query\"") },
                        leadingContent = { Icon(Icons.Filled.Add, null) },
                        modifier = Modifier.clickable { creating = true }
                    )
                }
                var lastCat = ""
                filtered.forEach { ex ->
                    if (ex.categoryName != lastCat) {
                        lastCat = ex.categoryName
                        item(key = "cat_${ex.categoryName}") { SectionTitle(ex.categoryName, Modifier.padding(horizontal = 16.dp)) }
                    }
                    item(key = ex.id) {
                        ListItem(
                            headlineContent = { Text(ex.name) },
                            leadingContent = { ColorDot(ex.color, 12) },
                            modifier = Modifier.clickable { open(ex.id) }
                        )
                    }
                }
            }
        }
    }
    if (creating) {
        ExerciseDialog(null, query, onDismiss = { creating = false }) { id ->
            creating = false
            open(id)
        }
    }
}

// =====================================================================
// Crear / editar ejercicio (compartido)
// =====================================================================

@Composable
fun ExerciseDialog(existing: Exercise?, initialName: String = "", onDismiss: () -> Unit, onSaved: (Long) -> Unit) {
    val scope = rememberCoroutineScope()
    val cats by load(emptyList<Category>()) { Repo.categories() }
    var name by remember { mutableStateOf(existing?.name ?: initialName) }
    var catId by remember { mutableStateOf(existing?.categoryId) }
    var newCat by remember { mutableStateOf("") }
    var type by remember { mutableIntStateOf(existing?.type ?: TYPE_STRENGTH) }
    var rest by remember { mutableStateOf((existing?.restSec ?: 90).toString()) }
    var menu by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Nuevo ejercicio" else "Editar ejercicio") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, singleLine = true)
                Box {
                    OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Grupo: " + (cats.firstOrNull { it.id == catId }?.name ?: if (newCat.isNotBlank()) newCat else "elegir…"))
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        cats.forEach { c ->
                            DropdownMenuItem(
                                text = { Text(c.name) },
                                leadingIcon = { ColorDot(c.color, 12) },
                                onClick = { catId = c.id; newCat = ""; menu = false }
                            )
                        }
                    }
                }
                OutlinedTextField(newCat, { newCat = it; if (it.isNotBlank()) catId = null },
                    label = { Text("…o grupo nuevo") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = type == TYPE_STRENGTH, onClick = { type = TYPE_STRENGTH }, label = { Text("Fuerza") })
                    FilterChip(selected = type == TYPE_CARDIO, onClick = { type = TYPE_CARDIO }, label = { Text("Cardio") })
                }
                NumField(rest, { rest = it }, "Descanso (segundos)", decimal = false)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isNotBlank()) {
                    var savedId = 0L
                    val n = name; val nc = newCat; val c = catId; val t = type; val r = rest.toIntOrNull() ?: 0
                    scope.write(after = { onSaved(savedId) }) {
                        val cid = if (nc.isNotBlank()) Repo.addCategory(nc) else c
                        savedId = Repo.saveExercise(existing?.id, n, cid, t, r)
                    }
                }
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

// =====================================================================
// Registro de series de un ejercicio
// =====================================================================

private data class LogData(
    val ex: Exercise,
    val sets: List<WorkoutSet>,
    val last: Pair<String, List<WorkoutSet>>?,
    val item: RoutineItem?,
    val bestBefore: Double,
    val suggestion: Suggestion?
)

@Composable
fun ExerciseLogScreen(exId: Long, date: String, nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dataState by load<LogData?>(null, exId, date) {
        val ex = Repo.exercise(exId)
        if (ex == null) null else {
            val last = Repo.lastSession(exId, date)
            val item = Repo.planItem(date, exId)
            LogData(
                ex, Repo.setsFor(date, exId), last, item, Repo.bestE1rmBefore(exId, date),
                item?.let { Stats.suggest(it, last?.second ?: emptyList()) }
            )
        }
    }
    val data = dataState
    if (data == null) {
        Screen("Cargando…", nav) { }
        return
    }
    val ex = data.ex
    val cardio = ex.type == TYPE_CARDIO

    var weight by rememberSaveable { mutableStateOf("") }
    var reps by rememberSaveable { mutableStateOf("") }
    var rpe by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    var dist by rememberSaveable { mutableStateOf("") }
    var time by rememberSaveable { mutableStateOf("") }
    var prefilled by rememberSaveable { mutableStateOf(false) }
    var editing by remember { mutableStateOf<WorkoutSet?>(null) }
    var confirmRemove by remember { mutableStateOf(false) }

    LaunchedEffect(data) {
        if (!prefilled) {
            val src = data.sets.lastOrNull() ?: data.last?.second?.firstOrNull()
            val sw = data.suggestion?.weight ?: src?.weight
            if (sw != null && sw > 0) weight = fmt(sw)
            val sr = data.suggestion?.reps ?: src?.reps
            if (sr != null && sr > 0) reps = sr.toString()
            if (src != null && src.distance > 0) dist = fmt(src.distance)
            if (src != null && src.durationSec > 0) time = fmtTime(src.durationSec)
            prefilled = true
        }
    }

    fun save() {
        val w = parseNum(weight) ?: 0.0
        val r = parseNum(reps)?.toInt() ?: 0
        val rp = parseNum(rpe)
        val di = parseNum(dist) ?: 0.0
        val du = parseTime(time)
        if (!cardio && r <= 0) { Toast.makeText(ctx, "Ingresa las repeticiones", Toast.LENGTH_SHORT).show(); return }
        if (cardio && di <= 0 && du <= 0) { Toast.makeText(ctx, "Ingresa distancia o tiempo", Toast.LENGTH_SHORT).show(); return }
        val ed = editing
        scope.write {
            if (ed != null) Repo.updateSet(ed.copy(weight = w, reps = r, rpe = rp, distance = di, durationSec = du, note = note.trim()))
            else Repo.addSet(date, exId, w, r, rp, di, du, note.trim())
        }
        if (ed == null) {
            RestTimer.start(ex.restSec)
            if (!cardio && Stats.e1rm(w, r) > maxOf(data.bestBefore, data.sets.maxOfOrNull { Stats.e1rm(it.weight, it.reps) } ?: 0.0) + 1e-9 && data.bestBefore > 0) {
                Toast.makeText(ctx, "🏆 ¡Nuevo récord! 1RM estimado ${fmt(Stats.e1rm(w, r))} kg", Toast.LENGTH_LONG).show()
            }
        }
        editing = null
        note = ""
        rpe = ""
    }

    Screen(
        ex.name, nav,
        actions = {
            IconButton(onClick = { RestTimer.start(if (ex.restSec > 0) ex.restSec else 90) }) { Icon(Icons.Filled.Timer, "Timer") }
            IconButton(onClick = { nav.navigate("stats/$exId") }) { Icon(Icons.Filled.Insights, "Historial y gráficos") }
            IconButton(onClick = { confirmRemove = true }) { Icon(Icons.Filled.Delete, "Quitar del día") }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            data.suggestion?.let { sg ->
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.TrendingUp, null)
                            Text("  " + sg.text, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (cardio) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                NumField(dist, { dist = it }, "Distancia (km)", Modifier.weight(1f))
                                OutlinedTextField(time, { time = it }, label = { Text("Tiempo (mm:ss)") }, singleLine = true, modifier = Modifier.weight(1f))
                            }
                        } else {
                            Stepper("Peso (kg)", weight, { weight = it }, 2.5)
                            Stepper("Reps", reps, { reps = it }, 1.0, decimal = false)
                            NumField(rpe, { rpe = it }, "RPE (opcional, 6-10)", Modifier.fillMaxWidth())
                        }
                        OutlinedTextField(note, { note = it }, label = { Text("Nota de la serie") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { save() }, modifier = Modifier.weight(1f)) {
                                Text(if (editing == null) "Guardar serie" else "Actualizar")
                            }
                            editing?.let { ed ->
                                OutlinedButton(onClick = {
                                    scope.write { Repo.deleteSet(ed.id) }
                                    editing = null
                                }) { Text("Borrar") }
                                TextButton(onClick = { editing = null }) { Text("Cancelar") }
                            }
                        }
                    }
                }
            }
            if (data.sets.isNotEmpty()) {
                item { SectionTitle("Hoy") }
                var best = data.bestBefore
                data.sets.forEachIndexed { i, s ->
                    val e = Stats.e1rm(s.weight, s.reps)
                    val isPr = !cardio && data.bestBefore > 0 && e > best + 1e-9
                    if (e > best) best = e
                    item(key = s.id) {
                        SetRow(i + 1, s, ex.type, isPr, selected = editing?.id == s.id) {
                            editing = s
                            weight = if (s.weight > 0) fmt(s.weight) else ""
                            reps = if (s.reps > 0) s.reps.toString() else ""
                            rpe = s.rpe?.let { fmt(it) } ?: ""
                            note = s.note
                            dist = if (s.distance > 0) fmt(s.distance) else ""
                            time = if (s.durationSec > 0) fmtTime(s.durationSec) else ""
                        }
                    }
                }
            }
            data.last?.let { (lastDate, lastSets) ->
                item { SectionTitle("Última vez · ${shortDate(lastDate)}") }
                lastSets.forEachIndexed { i, s ->
                    item(key = "last_${s.id}") { SetRow(i + 1, s, ex.type, false, false, null) }
                }
            }
        }
    }

    if (confirmRemove) {
        ConfirmDialog("Quitar ejercicio", "Se borrarán las series de ${ex.name} de este día.", { confirmRemove = false }) {
            confirmRemove = false
            scope.write(after = { nav.popBackStack() }) { Repo.removeFromDay(date, exId) }
        }
    }
}

@Composable
private fun Stepper(label: String, value: String, onChange: (String) -> Unit, step: Double, decimal: Boolean = true) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        FilledTonalIconButton(onClick = {
            val v = ((parseNum(value) ?: 0.0) - step).coerceAtLeast(0.0)
            onChange(fmt(v))
        }) { Icon(Icons.Filled.Remove, "Menos") }
        NumField(value, onChange, label, Modifier.weight(1f).padding(horizontal = 8.dp), decimal)
        FilledTonalIconButton(onClick = {
            val v = (parseNum(value) ?: 0.0) + step
            onChange(fmt(v))
        }) { Icon(Icons.Filled.Add, "Más") }
    }
}

@Composable
private fun SetRow(n: Int, s: WorkoutSet, type: Int, isPr: Boolean, selected: Boolean, onClick: (() -> Unit)?) {
    val mod = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
    Surface(
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        shape = MaterialTheme.shapes.small,
        modifier = Modifier.fillMaxWidth().then(mod)
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("$n", fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
            Column(Modifier.weight(1f)) {
                Text(setLabel(s, type), style = MaterialTheme.typography.bodyLarge)
                if (s.note.isNotBlank()) Text(s.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (isPr) Icon(Icons.Filled.EmojiEvents, "Récord", tint = MaterialTheme.colorScheme.primary)
        }
    }
}
