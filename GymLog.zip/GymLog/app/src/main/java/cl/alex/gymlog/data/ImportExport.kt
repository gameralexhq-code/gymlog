package cl.alex.gymlog.data

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.nio.charset.Charset
import java.text.Normalizer
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.zip.ZipInputStream

data class ImportResult(val imported: Int, val skipped: Int, val newExercises: Int, val badRows: Int, val message: String)

/**
 * Importa CSV de FitNotes (Spreadsheet Export) y planillas CSV/XLSX propias.
 * Reconoce columnas por nombre (español o inglés): Fecha/Date, Ejercicio/Exercise,
 * Categoría/Category/Grupo, Peso/Weight, Unidad, Reps, Series/Sets, Distancia, Tiempo, Nota/Comment, RPE.
 * Si una celda de fecha o ejercicio viene vacía, usa la de la fila anterior (celdas combinadas en Excel).
 * Importar dos veces el mismo archivo no duplica series.
 */
object Importer {

    fun import(ctx: Context, uri: Uri): ImportResult {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: return ImportResult(0, 0, 0, 0, "No se pudo leer el archivo.")
        val sheets: List<List<List<String>>> = try {
            if (bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) Xlsx.read(bytes)
            else listOf(Csv.parse(decode(bytes)))
        } catch (e: Exception) {
            return ImportResult(0, 0, 0, 0, "Formato no reconocido: ${e.message}")
        }
        var imported = 0; var skipped = 0; var newEx = 0; var bad = 0; var sheetsOk = 0
        Repo.tx {
            // Multiconjunto de series existentes para evitar duplicados
            val existing = HashMap<String, Int>()
            Repo.allSets().forEach { s -> existing.merge(key(s.date, s.exerciseId, s.weight, s.reps, s.distance, s.durationSec), 1, Int::plus) }
            val ordCounter = HashMap<String, Int>()

            for (rows in sheets) {
                val (headerIdx, cols) = findHeader(rows) ?: continue
                sheetsOk++
                var lastDate: LocalDate? = null
                var lastEx = ""
                var lastCat = ""
                for (r in (headerIdx + 1) until rows.size) {
                    val row = rows[r]
                    fun cell(k: String): String = cols[k]?.let { row.getOrNull(it) }?.trim() ?: ""
                    if (row.all { it.isBlank() }) continue
                    val date = parseDate(cell("date")) ?: lastDate
                    val exName = cell("exercise").ifEmpty { lastEx }
                    if (date == null || exName.isEmpty()) { bad++; continue }
                    if (cell("exercise").isNotEmpty() && cell("category").isEmpty()) lastCat = ""
                    val cat = cell("category").ifEmpty { lastCat }
                    lastDate = date; lastEx = exName; lastCat = cat

                    var weight = parseNum(cell("weight")) ?: 0.0
                    if (norm(cell("weightUnit")).startsWith("lb") || cols["weight"]?.let { norm(rows[headerIdx][it]).contains("lb") } == true) {
                        weight *= 0.45359237
                        weight = Math.round(weight * 100) / 100.0
                    }
                    val reps = parseNum(cell("reps"))?.toInt() ?: 0
                    var dist = parseNum(cell("distance")) ?: 0.0
                    val du = norm(cell("distanceUnit"))
                    if (du == "m" || du.startsWith("met")) dist /= 1000.0
                    if (du.startsWith("mi")) dist *= 1.609344
                    val dur = parseTime(cell("time"))
                    val rpe = parseNum(cell("rpe"))
                    val note = cell("comment")
                    val nSets = (parseNum(cell("sets"))?.toInt() ?: 1).coerceIn(1, 20)
                    if (weight == 0.0 && reps == 0 && dist == 0.0 && dur == 0) { bad++; continue }

                    val ex: Exercise = Repo.findExercise(exName) ?: run {
                        val catId = if (cat.isNotEmpty()) Repo.addCategory(cat) else null
                        val type = if (reps == 0 && (dist > 0 || dur > 0)) TYPE_CARDIO else TYPE_STRENGTH
                        val id = Repo.saveExercise(null, exName, catId, type, if (type == TYPE_CARDIO) 0 else 90)
                        newEx++
                        Repo.exercise(id)!!
                    }
                    val ds = date.toString()
                    repeat(nSets) {
                        val k = key(ds, ex.id, weight, reps, dist, dur)
                        val c = existing[k] ?: 0
                        if (c > 0) {
                            existing[k] = c - 1; skipped++
                        } else {
                            val ok = "$ds|${ex.id}"
                            val ord = ordCounter.getOrPut(ok) {
                                Repo.setsFor(ds, ex.id).maxOfOrNull { it.order } ?: 0
                            } + 1
                            ordCounter[ok] = ord
                            Repo.db.insert("workout_set", null, ContentValues().apply {
                                put("date", ds); put("exercise_id", ex.id); put("ord", ord); put("weight", weight)
                                put("reps", reps); put("rpe", rpe); put("distance", dist); put("duration", dur); put("note", note)
                            })
                            imported++
                        }
                    }
                }
            }
        }
        val msg = when {
            sheetsOk == 0 -> "No encontré encabezados reconocibles. La planilla necesita al menos columnas 'Fecha' y 'Ejercicio' (y Peso/Reps o Distancia/Tiempo)."
            else -> "Importadas $imported series. Omitidas $skipped (ya existían). Ejercicios nuevos: $newEx." +
                if (bad > 0) " Filas ignoradas: $bad." else ""
        }
        return ImportResult(imported, skipped, newEx, bad, msg)
    }

    private fun key(date: String, ex: Long, w: Double, r: Int, d: Double, t: Int) =
        "$date|$ex|${Math.round(w * 100)}|$r|${Math.round(d * 1000)}|$t"

    private fun decode(bytes: ByteArray): String {
        val utf = String(bytes, Charsets.UTF_8)
        val text = if (utf.contains('�')) String(bytes, Charset.forName("windows-1252")) else utf
        return text.removePrefix("﻿")
    }

    fun norm(s: String): String =
        Normalizer.normalize(s.lowercase().trim(), Normalizer.Form.NFD).replace(Regex("\\p{M}"), "")

    private fun findHeader(rows: List<List<String>>): Pair<Int, Map<String, Int>>? {
        for (i in 0 until minOf(rows.size, 15)) {
            val m = mapHeader(rows[i])
            if (m.containsKey("date") && m.containsKey("exercise")) return i to m
        }
        return null
    }

    private fun mapHeader(h: List<String>): Map<String, Int> {
        val m = HashMap<String, Int>()
        h.forEachIndexed { i, raw ->
            val n = norm(raw)
            val isUnit = n.contains("unit") || n.contains("unidad")
            val k = when {
                n == "date" || n.startsWith("fecha") || n == "dia" -> "date"
                n.startsWith("exercise") || n.startsWith("ejercicio") -> "exercise"
                n.startsWith("category") || n.startsWith("categoria") || n.startsWith("grupo") || n.startsWith("musculo") -> "category"
                (n.contains("weight") || n.contains("peso")) && isUnit -> "weightUnit"
                n.startsWith("weight") || n.startsWith("peso") || n == "kg" || n == "carga" -> "weight"
                (n.contains("distance") || n.contains("distancia")) && isUnit -> "distanceUnit"
                n.startsWith("distance") || n.startsWith("distancia") || n == "km" -> "distance"
                n.startsWith("rep") -> "reps"
                n == "sets" || n == "series" || n == "serie" -> "sets"
                n == "time" || n.startsWith("tiempo") || n.startsWith("duracion") -> "time"
                n.startsWith("comment") || n.startsWith("nota") || n.startsWith("comentario") || n.startsWith("observ") -> "comment"
                n == "rpe" -> "rpe"
                else -> null
            }
            if (k != null && !m.containsKey(k)) m[k] = i
        }
        return m
    }

    private val datePatterns = listOf("yyyy-MM-dd", "d/M/yyyy", "d-M-yyyy", "d.M.yyyy", "yyyy/M/d", "d/M/yy", "d-M-yy")
        .map { DateTimeFormatter.ofPattern(it) }

    fun parseDate(s: String): LocalDate? {
        val t = s.trim()
        if (t.isEmpty()) return null
        t.toDoubleOrNull()?.let { n ->
            if (n > 20000 && n < 80000) return LocalDate.of(1899, 12, 30).plusDays(n.toLong()) // fecha serial de Excel
            return null
        }
        val part = t.substringBefore('T').substringBefore(' ')
        for (f in datePatterns) {
            try { return LocalDate.parse(part, f) } catch (e: Exception) { }
        }
        return null
    }
}

object Csv {
    fun parse(text: String): List<List<String>> {
        val first = text.lineSequence().firstOrNull() ?: ""
        val delim = listOf(',', ';', '\t').maxByOrNull { d -> first.count { it == d } } ?: ','
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val sb = StringBuilder()
        var inQ = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (inQ) {
                if (c == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') { sb.append('"'); i++ } else inQ = false
                } else sb.append(c)
            } else {
                when (c) {
                    '"' -> inQ = true
                    delim -> { row.add(sb.toString()); sb.setLength(0) }
                    '\r' -> {}
                    '\n' -> { row.add(sb.toString()); sb.setLength(0); rows.add(row); row = ArrayList() }
                    else -> sb.append(c)
                }
            }
            i++
        }
        if (sb.isNotEmpty() || row.isNotEmpty()) { row.add(sb.toString()); rows.add(row) }
        return rows
    }

    fun esc(s: String): String =
        if (s.any { it == ',' || it == '"' || it == '\n' }) "\"" + s.replace("\"", "\"\"") + "\"" else s
}

/** Lector mínimo de .xlsx (sin librerías): devuelve todas las hojas como filas de texto. */
object Xlsx {
    fun read(bytes: ByteArray): List<List<List<String>>> {
        val entries = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (e.name.startsWith("xl/")) entries[e.name] = z.readBytes()
                e = z.nextEntry
            }
        }
        val shared = entries["xl/sharedStrings.xml"]?.let { parseShared(it) } ?: emptyList()
        val sheets = entries.keys
            .filter { it.startsWith("xl/worksheets/sheet") && it.endsWith(".xml") }
            .sortedBy { it.filter(Char::isDigit).toIntOrNull() ?: 999 }
        return sheets.map { parseSheet(entries.getValue(it), shared) }
    }

    private fun parser(b: ByteArray): XmlPullParser =
        Xml.newPullParser().apply { setInput(ByteArrayInputStream(b), "UTF-8") }

    private fun tag(p: XmlPullParser) = p.name.substringAfter(':')

    private fun parseShared(b: ByteArray): List<String> {
        val out = ArrayList<String>()
        val p = parser(b)
        var sb: StringBuilder? = null
        var inT = false
        var inPh = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (tag(p)) {
                    "si" -> sb = StringBuilder()
                    "t" -> inT = true
                    "rPh" -> inPh = true
                }
                XmlPullParser.TEXT -> if (inT && !inPh) sb?.append(p.text)
                XmlPullParser.END_TAG -> when (tag(p)) {
                    "si" -> { out.add(sb?.toString() ?: ""); sb = null }
                    "t" -> inT = false
                    "rPh" -> inPh = false
                }
            }
            ev = p.next()
        }
        return out
    }

    private fun colIndex(ref: String?): Int? {
        if (ref == null) return null
        var n = 0
        var any = false
        for (ch in ref) {
            if (ch.isLetter()) { n = n * 26 + (ch.uppercaseChar() - 'A' + 1); any = true } else break
        }
        return if (any) n - 1 else null
    }

    private fun parseSheet(b: ByteArray, shared: List<String>): List<List<String>> {
        val rows = ArrayList<List<String>>()
        val p = parser(b)
        var cells = HashMap<Int, String>()
        var col = 0
        var type: String? = null
        var value = StringBuilder()
        var inV = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (tag(p)) {
                    "row" -> { cells = HashMap(); col = 0 }
                    "c" -> {
                        col = colIndex(p.getAttributeValue(null, "r")) ?: col
                        type = p.getAttributeValue(null, "t")
                        value = StringBuilder()
                    }
                    "v", "t" -> inV = true
                }
                XmlPullParser.TEXT -> if (inV) value.append(p.text)
                XmlPullParser.END_TAG -> when (tag(p)) {
                    "v", "t" -> inV = false
                    "c" -> {
                        val raw = value.toString()
                        cells[col] = if (type == "s") raw.trim().toIntOrNull()?.let { shared.getOrNull(it) } ?: "" else raw
                        col++
                    }
                    "row" -> {
                        val max = cells.keys.maxOrNull() ?: -1
                        rows.add((0..max).map { cells[it] ?: "" })
                    }
                }
            }
            ev = p.next()
        }
        return rows
    }
}

object Exporter {
    /** CSV compatible con el formato de FitNotes (+ columna RPE). */
    fun exportCsv(ctx: Context, uri: Uri): Int {
        val ex = Repo.exercises().associateBy { it.id }
        val sets = Repo.allSets()
        ctx.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { w ->
            w.write("Date,Exercise,Category,Weight (kgs),Reps,Distance,Distance Unit,Time,Comment,RPE\n")
            sets.forEach { s ->
                val e = ex[s.exerciseId] ?: return@forEach
                val line = listOf(
                    s.date, Csv.esc(e.name), Csv.esc(e.categoryName),
                    if (s.weight > 0) fmt(s.weight) else "", if (s.reps > 0) s.reps.toString() else "",
                    if (s.distance > 0) fmt(s.distance) else "", if (s.distance > 0) "km" else "",
                    if (s.durationSec > 0) fmtTime(s.durationSec) else "", Csv.esc(s.note), s.rpe?.let { fmt(it) } ?: ""
                ).joinToString(",")
                w.write(line); w.write("\n")
            }
        } ?: throw IllegalStateException("No se pudo escribir el archivo")
        return sets.size
    }

    fun backupDb(ctx: Context, uri: Uri) {
        Repo.db.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { it.moveToFirst() }
        val f = Repo.dbFile()
        ctx.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            ?: throw IllegalStateException("No se pudo escribir el respaldo")
    }

    fun restoreDb(ctx: Context, uri: Uri) {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("No se pudo leer el archivo")
        if (bytes.size < 16 || String(bytes, 0, 15, Charsets.US_ASCII) != "SQLite format 3") {
            throw IllegalArgumentException("El archivo no es un respaldo de GymLog (.db)")
        }
        Repo.closeDb()
        val f = Repo.dbFile()
        listOf("-wal", "-shm", "-journal").forEach { java.io.File(f.path + it).delete() }
        f.writeBytes(bytes)
        Repo.init(ctx)
    }
}
