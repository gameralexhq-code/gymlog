package cl.alex.gymlog.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import java.time.LocalDate

private data class Tab(val route: String, val label: String, val icon: ImageVector)

@Composable
fun App() {
    val nav = rememberNavController()
    var date by rememberSaveable { mutableStateOf(LocalDate.now().toString()) }
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val tabs = listOf(
        Tab("log", "Entreno", Icons.Filled.FitnessCenter),
        Tab("routines", "Rutinas", Icons.Filled.Checklist),
        Tab("progress", "Progreso", Icons.Filled.Insights),
        Tab("body", "Cuerpo", Icons.Filled.MonitorWeight),
        Tab("more", "Más", Icons.Filled.MoreHoriz)
    )
    Scaffold(
        bottomBar = {
            Column {
                RestTimerBar()
                if (tabs.any { it.route == route }) {
                    NavigationBar {
                        tabs.forEach { t ->
                            NavigationBarItem(
                                selected = route == t.route,
                                onClick = {
                                    nav.navigate(t.route) {
                                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(t.icon, null) },
                                label = { Text(t.label) }
                            )
                        }
                    }
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "log", modifier = Modifier.padding(pad)) {
            composable("log") { LogScreen(date, { date = it }, nav) }
            composable("pick/{date}") { b -> ExercisePickerScreen(b.arguments?.getString("date") ?: date, nav) }
            composable(
                "exlog/{exId}/{date}",
                arguments = listOf(navArgument("exId") { type = NavType.LongType })
            ) { b ->
                ExerciseLogScreen(b.arguments?.getLong("exId") ?: 0L, b.arguments?.getString("date") ?: date, nav)
            }
            composable("routines") { RoutinesScreen(nav) }
            composable("routine/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { b ->
                RoutineEditScreen(b.arguments?.getLong("id") ?: 0L, nav)
            }
            composable("progress") { ProgressScreen(nav) }
            composable("stats/{exId}", arguments = listOf(navArgument("exId") { type = NavType.LongType })) { b ->
                ExerciseStatsScreen(b.arguments?.getLong("exId") ?: 0L, nav)
            }
            composable("body") { BodyScreen() }
            composable("more") { MoreScreen(nav) }
            composable("exercises") { ExercisesScreen(nav) }
        }
    }
}
