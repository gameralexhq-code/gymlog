package cl.alex.gymlog.data

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import java.util.Locale

data class Suggestion(val text: String, val weight: Double?, val reps: Int?)

data class PrEvent(val date: String, val exerciseName: String, val weight: Double, val reps: Int)

object Stats {
    /** 1RM estimado (fórmula de Epley). */
    fun e1rm(weight: Double, reps: Int): Double = when {
        reps <= 0 || weight <= 0 -> 0.0
        reps == 1 -> weight
        else -> weight * (1 + reps / 30.0)
    }

    fun volume(sets: List<WorkoutSet>): Double = sets.sumOf { it.weight * it.reps }

    /** Sugerencia de progresión doble: cuando todas las series llegan al tope de reps, se sube el peso. */
    fun suggest(item: RoutineItem, last: List<WorkoutSet>): Suggestion {
        val target = "${item.sets}×${item.repMin}-${item.repMax}"
        if (last.isEmpty()) return Suggestion("Objetivo $target. Sin historial: elige un peso cómodo.", null, item.repMin)
        val top = last.maxOf { it.weight }
        val work = last.filter { it.weight >= top - 0.001 }
        val allDone = work.size >= item.sets && work.all { it.reps >= item.repMax }
        return if (allDone) {
            val w = top + item.increment
            Suggestion("¡Sube! ${fmt(w)} kg × ${item.repMin}-${item.repMax} ($target). La vez pasada completaste todo.", w, item.repMin)
        } else {
            val bestReps = work.maxOf { it.reps }
            Suggestion("Mantén ${fmt(top)} kg y busca ${item.repMax} reps en las ${item.sets} series (objetivo $target).", top, (bestReps + 1).coerceAtMost(item.repMax))
        }
    }

    fun weekStart(d: LocalDate): LocalDate = d.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

    /** Récords de 1RM estimado (cada vez que se superó el mejor anterior). */
    fun prEvents(rows: List<StatRow>): List<PrEvent> {
        val best = HashMap<Long, Double>()
        val out = ArrayList<PrEvent>()
        rows.filter { it.type == TYPE_STRENGTH }.forEach { r ->
            val e = e1rm(r.weight, r.reps)
            val prev = best[r.exerciseId]
            if (e > 0 && (prev == null || e > prev + 1e-9)) {
                if (prev != null) out.add(PrEvent(r.date, r.exerciseName, r.weight, r.reps))
                best[r.exerciseId] = e
            }
        }
        return out
    }
}

fun fmt(d: Double): String =
    if (d % 1.0 == 0.0) d.toLong().toString()
    else String.format(Locale.US, "%.2f", d).trimEnd('0').trimEnd('.')

fun fmtTime(sec: Int): String {
    val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%d:%02d", m, s)
}

/** Acepta "62,5", "62.5", "62.5 kg". */
fun parseNum(s: String?): Double? {
    if (s == null) return null
    var t = s.trim().replace(Regex("[^0-9.,\\-]"), "")
    if (t.isEmpty()) return null
    t = if (t.contains(',') && !t.contains('.')) t.replace(',', '.') else t.replace(",", "")
    return t.toDoubleOrNull()
}

/** Acepta "1:02:30", "25:00", "90" (segundos) o "90s". */
fun parseTime(s: String?): Int {
    if (s == null) return 0
    val t = s.trim()
    if (t.isEmpty()) return 0
    if (t.contains(':')) {
        val p = t.split(':').map { it.trim().toDoubleOrNull() ?: 0.0 }
        return when (p.size) {
            2 -> (p[0] * 60 + p[1]).toInt()
            3 -> (p[0] * 3600 + p[1] * 60 + p[2]).toInt()
            else -> 0
        }
    }
    return parseNum(t)?.toInt() ?: 0
}

fun setLabel(s: WorkoutSet, type: Int): String =
    if (type == TYPE_CARDIO) {
        buildList {
            if (s.distance > 0) add("${fmt(s.distance)} km")
            if (s.durationSec > 0) add(fmtTime(s.durationSec))
            if (s.distance > 0 && s.durationSec > 0) add("${fmtTime((s.durationSec / s.distance).toInt())}/km")
        }.joinToString(" · ").ifEmpty { "—" }
    } else {
        val base = if (s.weight > 0) "${fmt(s.weight)} kg × ${s.reps}" else "${s.reps} reps"
        if (s.rpe != null) "$base @${fmt(s.rpe)}" else base
    }
