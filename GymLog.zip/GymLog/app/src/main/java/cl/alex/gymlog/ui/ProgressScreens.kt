package cl.alex.gymlog.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import cl.alex.gymlog.data.*
import java.time.LocalDate

// =====================================================================
// Resumen de progreso
// =====================================================================

private data class CatLoad(val name: String, val color: Long, val last7: Int, val avg4w: Double)

private data class ProgressData(
    val cats: List<CatLoad>,
    val weekLabels: List<String>,
    val weekVolume: List<Double>,
    val weekSessions: List<Double>,
    val prs: List<PrEvent>,
    val exercises: List<Pair<Exercise, Int>>,
    val sessionsMonth: Int
)

private fun buildProgress(): ProgressData {
    val today = LocalDate.now()
    val all = Repo.statRows("0000-00-00")
    val from12 = Stats.weekStart(today).minusWeeks(11)
    val d7 = today.minusDays(6).toString()
    val d35 = today.minusDays(34).toString()
    val strength = all.filter { it.type == TYPE_STRENGTH }

    val byCat = strength.filter { it.date >= d35 }.groupBy { it.category }
    val cats = byCat.map { (name, rows) ->
        val last7 = rows.count { it.date >= d7 }
        val prev4 = rows.count { it.date < d7 }
        CatLoad(name, rows.first().color, last7, prev4 / 4.0)
    }.sortedByDescending { it.last7 + it.avg4w }

    val weeks = (0 until 12).map { from12.plusWeeks(it.toLong()) }
    val volMap = strength.filter { it.date >= from12.toString() }
        .groupBy { Stats.weekStart(LocalDate.parse(it.date)) }
        .mapValues { (_, rows) -> rows.sumOf { it.weight * it.reps } }
    val sesMap = all.filter { it.date >= from12.toString() }
        .groupBy { Stats.weekStart(LocalDate.parse(it.date)) }
        .mapValues { (_, rows) -> rows.map { it.date }.distinct().size.toDouble() }

    val prs = Stats.prEvents(all).filter { it.date >= today.minusDays(30).toString() }.reversed()
    val month = today.withDayOfMonth(1).toString()
    return ProgressData(
        cats,
        weeks.map { shortDate(it.toString()) },
        weeks.map { volMap[it] ?: 0.0 },
        weeks.map { sesMap[it] ?: 0.0 },
        prs.take(15),
        Repo.exercisesWithHistory().sortedByDescending { it.second },
        all.filter { it.date >= month }.map { it.date }.distinct().size
    )
}

@Composable
fun ProgressScreen(nav: NavController) {
    val data by load<ProgressData?>(null) { buildProgress() }
    var chart by rememberSaveable { mutableIntStateOf(0) }
    Screen("Progreso") { pad ->
        val p = data
        if (p == null) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Screen
        }
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            item {
                Text("Entrenamientos este mes: ${p.sessionsMonth}", style = MaterialTheme.typography.titleMedium)
            }
            item { SectionTitle("Series por grupo muscular · últimos 7 días (promedio 4 semanas previas)") }
            if (p.cats.isEmpty()) item { Text("Aún no hay series en el último mes.", style = MaterialTheme.typography.bodySmall) }
            else {
                val maxV = p.cats.maxOf { maxOf(it.last7.toDouble(), it.avg4w) }.coerceAtLeast(1.0)
                items(p.cats, key = { "c_" + it.name }) { c ->
                    HBar(c.name, (c.last7 / maxV).toFloat(), Color(c.color), "${c.last7} (≈${fmt(Math.round(c.avg4w * 10) / 10.0)})")
                }
            }
            item {
                SectionTitle("Últimas 12 semanas")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(chart == 0, { chart = 0 }, { Text("Volumen (kg)") })
                    FilterChip(chart == 1, { chart = 1 }, { Text("Sesiones") })
                }
                if (chart == 0) LineChart(p.weekVolume, p.weekLabels, "kg")
                else LineChart(p.weekSessions, p.weekLabels, "")
            }
            if (p.prs.isNotEmpty()) {
                item { SectionTitle("Récords recientes (1RM estimado, 30 días)") }
                items(p.prs.size) { i ->
                    val pr = p.prs[i]
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                        Icon(Icons.Filled.EmojiEvents, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Text("  ${pr.exerciseName}: ${fmt(pr.weight)} kg × ${pr.reps}", modifier = Modifier.weight(1f))
                        Text(shortDate(pr.date), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item { SectionTitle("Ejercicios (toca para ver gráficos y récords)") }
            if (p.exercises.isEmpty()) item { Text("Registra o importa entrenamientos para ver estadísticas.", style = MaterialTheme.typography.bodySmall) }
            items(p.exercises, key = { "e_" + it.first.id }) { (ex, n) ->
                ListItem(
                    headlineContent = { Text(ex.name) },
                    supportingContent = { Text("${ex.categoryName} · $n sesiones") },
                    leadingContent = { ColorDot(ex.color, 12) },
                    modifier = Modifier.clickable { nav.navigate("stats/${ex.id}") }
                )
            }
        }
    }
}

// =====================================================================
// Estadísticas de un ejercicio
// =====================================================================

private data class Session(val date: String, val sets: List<WorkoutSet>)

@Composable
fun ExerciseStatsScreen(exId: Long, nav: NavController) {
    val ex by load<Exercise?>(null, exId) { Repo.exercise(exId) }
    val hist by load(emptyList<WorkoutSet>(), exId) { Repo.history(exId) }
    var metric by rememberSaveable { mutableIntStateOf(0) }
    var range by rememberSaveable { mutableIntStateOf(3) }
    val e = ex
    Screen(e?.name ?: "Estadísticas", nav) { pad ->
        if (e == null) return@Screen
        val cardio = e.type == TYPE_CARDIO
        val sessions = hist.groupBy { it.date }.map { Session(it.key, it.value) }.sortedBy { it.date }
        val today = LocalDate.now()
        val from = when (range) {
            0 -> today.minusMonths(3).toString()
            1 -> today.minusMonths(6).toString()
            2 -> today.minusYears(1).toString()
            else -> ""
        }
        val shown = sessions.filter { it.date >= from }
        val metrics = if (cardio) listOf("Distancia", "Tiempo", "Ritmo (min/km)") else listOf("1RM estimado", "Peso máx", "Volumen", "Reps máx")
        val m = metric.coerceAtMost(metrics.size - 1)
        val values: List<Double> = shown.map { s ->
            if (cardio) {
                val d = s.sets.sumOf { it.distance }
                val t = s.sets.sumOf { it.durationSec }
                when (m) {
                    0 -> d
                    1 -> t / 60.0
                    else -> if (d > 0) t / 60.0 / d else 0.0
                }
            } else when (m) {
                0 -> s.sets.maxOf { Stats.e1rm(it.weight, it.reps) }
                1 -> s.sets.maxOf { it.weight }
                2 -> Stats.volume(s.sets)
                else -> s.sets.maxOf { it.reps }.toDouble()
            }
        }
        val unit = if (cardio) listOf("km", "min", "min/km")[m] else listOf("kg", "kg", "kg", "reps")[m]

        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    metrics.forEachIndexed { i, label -> FilterChip(m == i, { metric = i }, { Text(label) }) }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("3M", "6M", "1A", "Todo").forEachIndexed { i, label -> FilterChip(range == i, { range = i }, { Text(label) }) }
                }
                LineChart(values.map { Math.round(it * 10) / 10.0 }, shown.map { shortDate(it.date) }, unit)
            }
            if (!cardio && hist.isNotEmpty()) {
                item {
                    val best = hist.maxBy { Stats.e1rm(it.weight, it.reps) }
                    val heaviest = hist.maxBy { it.weight }
                    SectionTitle("Récords")
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("1RM estimado: ${fmt(Math.round(Stats.e1rm(best.weight, best.reps) * 10) / 10.0)} kg", fontWeight = FontWeight.Bold)
                            Text("   con ${fmt(best.weight)} kg × ${best.reps} · ${shortDate(best.date)}", style = MaterialTheme.typography.bodySmall)
                            Text("Peso máximo: ${fmt(heaviest.weight)} kg × ${heaviest.reps} · ${shortDate(heaviest.date)}")
                            Text("Volumen máx en una sesión: ${fmt(sessions.maxOf { Stats.volume(it.sets) })} kg")
                        }
                    }
                    SectionTitle("Mejor peso por repeticiones")
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            (1..12).forEach { r ->
                                val s = hist.filter { it.reps >= r }.maxByOrNull { it.weight }
                                if (s != null) Row {
                                    Text("$r RM", modifier = Modifier.width(56.dp), fontWeight = FontWeight.Bold)
                                    Text("${fmt(s.weight)} kg", modifier = Modifier.weight(1f))
                                    Text(shortDate(s.date), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
            item { SectionTitle("Historial") }
            items(sessions.reversed(), key = { it.date }) { s ->
                Column(Modifier.padding(vertical = 4.dp)) {
                    Text(shortDate(s.date), fontWeight = FontWeight.Bold)
                    Text(s.sets.joinToString("  ·  ") { setLabel(it, e.type) }, style = MaterialTheme.typography.bodyMedium)
                    s.sets.filter { it.note.isNotBlank() }.forEach {
                        Text("“${it.note}”", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                HorizontalDivider()
            }
        }
    }
}
