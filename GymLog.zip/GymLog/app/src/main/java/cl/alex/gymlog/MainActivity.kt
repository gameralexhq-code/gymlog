package cl.alex.gymlog

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import cl.alex.gymlog.data.Repo
import cl.alex.gymlog.ui.App
import cl.alex.gymlog.ui.GymTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.init(applicationContext)
        setContent {
            GymTheme {
                App()
            }
        }
    }
}
